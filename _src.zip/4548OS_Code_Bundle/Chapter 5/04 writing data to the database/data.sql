CREATE TABLE `CustomTable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
);