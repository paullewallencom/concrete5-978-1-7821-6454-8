<?php 
defined('C5_EXECUTE') or die("Access Denied.");

class BlogPost extends Model {
	var $_table = 'BlogPosts';
}