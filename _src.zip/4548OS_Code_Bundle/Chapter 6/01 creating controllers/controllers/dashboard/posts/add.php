<?php 
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardPostsAddController extends Controller {

}