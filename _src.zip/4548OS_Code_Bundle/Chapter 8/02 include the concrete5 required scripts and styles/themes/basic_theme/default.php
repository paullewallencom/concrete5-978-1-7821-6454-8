<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Super Basic Theme</title>
    <?php Loader::element('header_required') ?>
</head>
<body>
    <h1>Hi, this is my super basic theme. It's really boring.</h1>
    <?php Loader::element('footer_required') ?>
</body>
</html>