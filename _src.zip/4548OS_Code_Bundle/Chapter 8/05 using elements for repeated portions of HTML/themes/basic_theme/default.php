<?php $this->inc('elements/header.php'); ?>
    <?php $a = new Area('content'); $a->display($c); ?>
<?php $this->inc('elements/footer.php'); ?>