<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Super Basic Theme</title>
</head>
<body>
    <h1>Hi, this is my super basic theme. It's really boring.</h1>
</body>
</html>