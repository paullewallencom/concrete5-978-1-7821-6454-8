<?php   

defined('C5_EXECUTE') or die(_("Access Denied."));

$v = View::getInstance();
$v->setThemeByPath('/login', "basic_theme");