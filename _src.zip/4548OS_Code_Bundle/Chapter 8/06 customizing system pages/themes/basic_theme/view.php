<?php $this->inc('elements/header.php'); ?>
	<?php print $innerContent ?>
<?php $this->inc('elements/footer.php'); ?>