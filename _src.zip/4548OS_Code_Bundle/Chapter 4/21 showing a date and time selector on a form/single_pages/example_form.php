<?php 
   $datePicker = Loader::helper('form/date_time');
?>

<form>
   <?php echo $datePicker->date('date') ?>
</form>