<?php

Config::save('allow_comments', true);
$allowComments = Config::get('allow_comments');