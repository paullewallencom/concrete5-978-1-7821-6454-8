<?php
$subject = 'Hello from your website!';
$body = 'This is the body! Hello, '.$name;