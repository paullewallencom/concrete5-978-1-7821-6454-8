<?php 
   $rh = Loader::helper('form/rating');
?>

<form>
   <?php echo $rh->rating('rating', 60) ?>
</form>