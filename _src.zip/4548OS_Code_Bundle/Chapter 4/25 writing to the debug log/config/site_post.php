<?php

$message = 'Hello, log!';
Log::addEntry($message);