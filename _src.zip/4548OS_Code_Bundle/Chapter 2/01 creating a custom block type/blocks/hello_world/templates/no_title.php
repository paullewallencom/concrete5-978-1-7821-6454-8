<div class="content">
	<?php echo $content ?>
</div>