hello_world custom block type:
	
1. Drag hello_world folder to the root /blocks directory of a concrete5 website. 
2. Log into the site and visit this page: http://yoursite.com/index.php/dashboard/blocks/types/
3. Click the install button on the Hello World block.
4. Return to the front end portion of your website
5. Edit a page, add the new block to a content area.