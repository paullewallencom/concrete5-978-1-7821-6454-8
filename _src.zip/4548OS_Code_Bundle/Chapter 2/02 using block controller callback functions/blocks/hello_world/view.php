<h1><?php echo $title ?></h1>
<div class="content">
   <?php echo $name ?>
</div>