<?php

$block = BlockType::getByHandle('hello_world');
print_r($block);
exit;