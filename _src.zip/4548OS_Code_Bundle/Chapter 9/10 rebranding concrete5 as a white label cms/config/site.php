<?php 
/*
Use your own credentials here.

define('DB_SERVER', '127.0.0.1');
define('DB_USERNAME', 'user');
define('DB_PASSWORD', 'password');
define('DB_DATABASE', 'dbname');
define('PASSWORD_SALT', 'passwordsalt123');
*/

define('WHITE_LABEL_LOGO_SRC', '/images/new-logo.png');