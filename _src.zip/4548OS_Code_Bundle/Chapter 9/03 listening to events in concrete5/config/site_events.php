<?php
Events::extend('on_start', 'MyClass', 'onStartFired', 'libraries/my_class.php');