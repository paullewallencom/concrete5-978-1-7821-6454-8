<?php
class MyClass {

	public function onStartFired() {
		die('hello world!');
	}

}