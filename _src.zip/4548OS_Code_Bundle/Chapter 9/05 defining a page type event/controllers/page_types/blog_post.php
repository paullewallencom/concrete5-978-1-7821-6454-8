<?php
class BlogPostPageTypeController extends Controller {

	public function on_page_add() {
		die('blog post added');
	}

}