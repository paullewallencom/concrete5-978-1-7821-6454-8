<?php
Events::extendPageType('blog_post', 'on_page_add');