<?php

$str = 'Hello world!';

echo t($str);
exit;