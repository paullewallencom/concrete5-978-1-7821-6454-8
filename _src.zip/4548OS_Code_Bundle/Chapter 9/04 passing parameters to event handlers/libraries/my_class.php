<?php
class MyClass {

	public function onStartFired($view, $message) {
		die($message);
	}

}