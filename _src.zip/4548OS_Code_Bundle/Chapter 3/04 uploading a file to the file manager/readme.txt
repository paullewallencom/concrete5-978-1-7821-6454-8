Copy the files in this directory to your concrete5 site.
Install the single page by visiting /dashboard/pages/single and entering "upload" as the page location.