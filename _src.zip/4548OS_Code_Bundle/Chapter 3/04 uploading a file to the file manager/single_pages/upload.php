<form method="POST" enctype="multipart/form-data">
   File to upload: <input type="file" name="example_file"><br />
   <input type="hidden" name="file_upload" value="yes">
   <input type="submit" value="Upload!">
</form>