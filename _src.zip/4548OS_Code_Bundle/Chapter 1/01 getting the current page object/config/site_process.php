<?php
$currentPage = Page::getCurrentPage();
my_debug($currentPage);