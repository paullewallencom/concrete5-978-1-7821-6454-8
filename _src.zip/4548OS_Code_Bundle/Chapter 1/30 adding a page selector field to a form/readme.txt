1. Copy the example.php file from single_pages/ to your concrete5 site's /single_pages directory.
2. Visit /dashboard/pages/single
3. Add a new single page with the page of /example
4. Visit /example on your site to see the single page in action.